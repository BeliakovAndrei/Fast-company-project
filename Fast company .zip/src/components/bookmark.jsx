import React from "react";

const BookMark = ({status, ...rest}) => {
<i className={"bi bi-bookmark" + (status ? "-heart-fill" : "")}></i> 
};

export default BookMark;